#!/bin/bash
#SBATCH --job-name=toma16x16_mc10
#SBATCH -p cpu
#SBATCH -N 1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --mem=24G
#SBATCH --time=48:00:00
#SBATCH -o %j.out
#SBATCH -e %j.err
set -euo pipefail

PROJECT_ROOT="${PROJECT_ROOT:-/home/lyq00008339/Lihuang_Li/toma_ground_disk_mc10_20261022}"
CONDA_SH="${CONDA_SH:-/home/lyq00008339/miniconda3/etc/profile.d/conda.sh}"
. "$CONDA_SH"
conda activate "${TARGET_CONDA_ENV:-JM_CVX}"
cd "$PROJECT_ROOT"
PYTHON_BIN="${HPC_PYTHON:-python}"
WORKERS="${SLURM_CPUS_PER_TASK:?Submit through sbatch}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 BLIS_NUM_THREADS=1 MPLBACKEND=Agg PYTHONDONTWRITEBYTECODE=1
export MPLCONFIGDIR="${TMPDIR:-/tmp}/toma_disk_mpl_${SLURM_JOB_ID}"
OUTPUT_DIR="${HPC_OUTPUT:-${PROJECT_ROOT}/results/tradeoff_mc10_${SLURM_JOB_ID}}"
"$PYTHON_BIN" -c 'import json; b=json.load(open("tradeoff_config.json")); assert all("ground_disk" in m["experiment"] for m in b["models"].values()), "Ground geometry is not configured: run configure_trial.py first"'
echo "CPUs=$WORKERS; dynamic independent tasks=800; scenes=8001..8010; output=$OUTPUT_DIR"
"$PYTHON_BIN" -u run_figures.py --config tradeoff_config.json --figures tradeoff --n-mc 10 --check-only
"$PYTHON_BIN" -u run_figures.py --config tradeoff_config.json --figures tradeoff --n-mc 10 \
    --workers "$WORKERS" --output "$OUTPUT_DIR"
