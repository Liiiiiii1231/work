# 五图分别提交，共用一份模型与算法

集群工程根目录固定为 `/home/lyq00008339/Lihuang_Li/toma`。五个子目录与用户确认的目录名完全一致。

```text
toma/
├── system_model.py              # 参数、状态、几何、约束、用户场景
├── channel_model.py             # 信道、速率、MRT 等资源初始化
├── inner_solver.py              # 内层 FP
├── outer_solver.py              # 外层位置优化
├── algorithms.py                # 联合算法及四方案调度
├── figure_engine.py             # 多起点、断点校验、汇总和绘图
├── run_figures.py               # 共用运行器，子目录入口调用它
├── simulation_config.json       # 原配置，保持不变
├── tradeoff_config.json         # 新权重配置，加入 w=0 和 w=1
├── README.md
├── 01_proposed_convergence/
│   ├── run_convergence.py
│   ├── submit_convergence.sh
│   └── results/
├── 02_wsr_vs_p_dl_max/
│   ├── run_p_dl_max.py
│   ├── submit_p_dl_max.sh
│   └── results/
├── 03_wsr_vs_rho_si/
│   ├── run_rho_si.py
│   ├── submit_rho_si.sh
│   └── results/
├── 04_wsr_vs_system_load/
│   ├── run_system_load.py
│   ├── submit_system_load.sh
│   └── results/
└── 05_communication_sensing_tradeoff/
    ├── run_tradeoff.py
    ├── submit_tradeoff.sh
    └── results/
```

## 上传

根目录共 10 个文件，首次部署可一次上传；再分别进入五个图目录，每个目录上传对应的 2 个脚本。不需要把系统模型和算法复制进各图目录。`.sh` 也可直接粘贴到平台作业脚本编辑器。

如果原 `toma` 根目录已有之前的 9 个文件，只需新增 `tradeoff_config.json`，并给五个子目录放入对应 `.py` 和 `.sh`。无需覆盖共用 Python 或原 `simulation_config.json`，避免影响仍在运行的旧作业。README 可按需更新。`results/` 可以不预建，脚本会自动创建。

## 先运行权重图

平台作业脚本中使用 `05_communication_sensing_tradeoff/submit_tradeoff.sh` 的全部内容，申请 1 节点、50 CPU、48 GB；不使用作业数组。脚本使用固定的工程和图目录绝对路径，默认激活 `JM_CVX`，Conda 初始化路径沿用用户提供的模板。环境需有 NumPy、SciPy、matplotlib；不需要 CVX、CVXPY、MOSEK 或 yaml。

终端提交示例：

```bash
sbatch /home/lyq00008339/Lihuang_Li/toma/05_communication_sensing_tradeoff/submit_tradeoff.sh
```

每个单图作业内部最多同时运行 50 个场景进程，每进程使用 1 CPU，空闲后自动领取下一个场景。单图仍为 100 个蒙特卡洛场景，不是将同一个场景重复 50 次。每张图单独提交会申请 50 CPU；需要一张一张跑时，等上一张结束再提交下一张。若决定停止原全图作业切换到本方案，先在平台结束旧作业并保留其结果；新脚本不会自动取消任何作业。

## 权重点与冻结协议

权重图保留原 16 个权重点，新增精确端点，共 18 点：

```text
0, 0.001, 0.015, 0.16, 0.18, 0.20, 0.42, 0.46, 0.50,
0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 1
```

目标为 `w*(R_DL+R_UL)/10 + (1-w)*R_S/5`：w=0 只优化感知目标；w=1 只优化通信目标。未加权的一类速率仍按实际系统计算，不强制为零。

四方案、100 场景、18 权重点，共 7200 次起点优化。权重图每个方案一个规则起点，跨权重共用相同初始天线位置和资源种子 2042；无跨权重 warm start。初始上行功率 25 mW、内外层绝对容差 1e-4、用户位置随场景变化等协议保持不变。

其他四图使用原 `simulation_config.json`，Proposed 5 起点、MA 3 起点、固定 ToMA/UPA 各 1 起点。所有图共用根目录相同模型、初始化和求解算法。

## 结果保存与续跑

每次提交使用独立结果目录。例如权重图作业 ID 为 35000 时：

```text
/home/lyq00008339/Lihuang_Li/toma/05_communication_sensing_tradeoff/results/run_35000/
├── figures/                    # PNG、PDF、SVG
├── tables/                     # 起点、逐场景、均值
├── candidate_*/tasks/           # 初始状态、优化状态、历史与收敛记录
├── metadata/
├── logs/                       # scene_0.out/.err 至 scene_99.out/.err
├── status.json
└── completion.json
```

其他图同样保存到各自目录的 `results/run_作业ID/`。Slurm 的 `%j.out/%j.err` 主日志仍由平台写在作业启动目录；详细计算日志在上述结果目录中。

每个脚本最长 48 小时，这不是完成时间保证。一次调用达到迭代上限但未收敛时，从当前状态继续，最多 20 次调用；每次调用返回后保存断点。若超时终止或耗尽调用预算，指定原目录后重交对应图脚本即可：

```bash
export HPC_OUTPUT=/home/lyq00008339/Lihuang_Li/toma/05_communication_sensing_tradeoff/results/run_35000
sbatch /home/lyq00008339/Lihuang_Li/toma/05_communication_sensing_tradeoff/submit_tradeoff.sh
```

不要同时提交两个写入同一图、同一输出目录的作业。新增端点的权重配置与旧全图作业的协议身份不同，使用新的单图结果目录；旧结果仍保留在原 `toma/results/all_mc100_33336/`，不会被移动或覆盖。

## 本地预检

在具备依赖的环境中执行：

```bash
python 05_communication_sensing_tradeoff/run_tradeoff.py --check-only
```

其余图使用各自 `run_*.py --check-only`。这些入口固定单图，正式汇总要求全部预期场景和起点有效且收敛，缺失时不会做部分平均。代码或配置变更后使用新结果目录。
