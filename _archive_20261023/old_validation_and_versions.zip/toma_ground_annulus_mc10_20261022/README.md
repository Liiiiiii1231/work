# 多方向地面圆环：16发16收，10场景权重图试跑

## 已确认的物理设置

主无人机离地20米。计算坐标以主无人机为原点，地面z=-20米。
基准斜距40米对应水平半径sqrt(40^2-20^2)=34.64101615137755米。
水平半径在基准上下10米内变化，即24.64101615137755至44.64101615137755米。
圆环以主无人机正下方为中心，方位0至360度，各类对象均可出现在任意方向。
5个DL用户、5个UL用户、5个目标独立按圆环面积均匀采样；不强制等角间隔或每个扇区固定人数。
采样公式r=sqrt(r_min^2+U*(r_max^2-r_min^2))，theta~Uniform(0,2*pi)。
地面坐标(x,y,z)=(r*cos(theta),r*sin(theta),-20)。不会再叠加旧正方形扰动。
同场景跨权重和方案坐标完全一致；不同场景重新采样，无累积位移。

收发各4架子无人机，M=8；每根1米缆绳4个阵元，距锚点0.25、0.5、0.75、1米。
每侧16个阵元。感知因子列数R_s保持原配置，5目标基准仍为4。
纯LoS、RCS、噪声、功率上限、初始上行25mW、绝对停止容差1e-4及求解器保持原设置。
仍沿用原模型忽略UL到DL交叉干扰的假设。

## 任务和CPU

默认只运行权重图，场景8001至8010，20个原权重、4方案、单起点，共800项独立优化任务。
各权重点独立初始化，不使用邻近权重热启动。
10个工作进程动态从任务队列取任务，每进程BLAS单线程；Slurm申请10核、24GB、48小时。
工作进程数自动读取SLURM_CPUS_PER_TASK，避免申请核数和进程数不一致。
动态队列减少按场景分组造成的尾部空闲；实际CPU效率和加速比仍以平台运行记录为准。

## 上传和提交

请使用本圆环版本，旧ground_disk包对应另一种场景。不要覆盖原工程或混用旧输出。
解压整个文件夹至：

    /home/lyq00008339/Lihuang_Li/toma_ground_annulus_mc10_20261022

提交：

    cd /home/lyq00008339/Lihuang_Li/toma_ground_annulus_mc10_20261022
    sbatch submit_tradeoff_mc10.sh

若希望申请原平台的50核：

    sbatch --cpus-per-task=50 --mem=48G submit_tradeoff_mc10.sh

默认使用cpu分区和JM_CVX环境。默认输出results/tradeoff_mc10_作业ID。
未完成时保留源代码、配置和全部检查点，通过HPC_OUTPUT指定同一目录续跑：

    HPC_OUTPUT=/绝对路径/results/tradeoff_mc10_原作业ID sbatch submit_tradeoff_mc10.sh

源代码和配置身份校验保持开启，不复用旧圆面结果。
只有800项全部收敛后才完整汇总10场景均值与图，不使用缺失场景的部分均值。

## 验证范围

已执行check-only以及validate_trial.py：检查10个场景的地面圆环范围、跨权重/方案一致性，
并通过2进程执行12项短程优化，检查约束、有限数值和目标非下降。
validation_report.json保存结果。这些是截短预算的运行检查，不是10次MC性能结果。
未代用户提交集群作业。

## 结束后自动汇总与打包

submit_tradeoff_mc10.sh已设置EXIT处理：Python正常结束或报错返回后均执行finalize_run.py。
主程序运行输出同步写入logs/console.log；可用的Slurm输出和错误文件复制一份快照。

- results/tradeoff_mc10_作业ID/all_data.json：一个汇总文件，包含全部CSV表、JSON记录及元数据、全部NPZ中的初态/终态/中间检查点数值与迭代历史、文本日志、源码和配置快照。
- 复数矩阵分开保存real和imag，并保留dtype和shape；CSV单元格保留原文本。
- results/tradeoff_mc10_作业ID_bundle.zip：包含整个输出目录、all_data.json、原始NPZ、图表和provenance源码配置快照。
- 汇总文件保留运行退出码及完成标记；失败结果不会标记为完整MC结果。
- ZIP位于输出目录外，避免把压缩包自身再次打入包内；生成后执行完整性检查，原始文件保留。

若作业被平台强制终止而未完成导出，可在相同Python环境手动运行：

    python finalize_run.py --output /绝对路径/results/tradeoff_mc10_作业ID --run-exit-code 1

新增脚本也属于源代码身份校验的一部分；已开始的旧版本作业不要直接换源码续跑，应先保留其原工程。
